/**
 * vim: set ts=4 sw=4 tw=99 noet :
 * ======================================================
 * Metamod:Source Menu System
 * Written by Wend4r & komashchenko (Vladimir Ezhikov & Borys Komashchenko).
 * ======================================================

 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.

 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.

 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */


#ifndef _INCLUDE_METAMOD_SOURCE_IMENU_HPP_
#	define _INCLUDE_METAMOD_SOURCE_IMENU_HPP_

#	pragma once

#	include "imenuinstance.hpp"
#	include <basetypes.h>
#	include <playerslot.h>
#	if __has_include(<tier0/utlstring.h>)
#		include <tier0/utlstring.h>
#	else // Bcompatibility with HL2SDK
#		include <tier1/utlstring.h>
#	endif // __has_include(<tier0/utlstring.h>)
#	include <tier1/utlvector.h>

/**
 * @file imenu.hpp
 * @brief Defines an IMenu interface for managing in-game menus.
 */

#	define MENU_FIRST_ITEM_INDEX 0  ///< The menu first item index.
#	define MENU_NO_PAGINATION 0     ///< Menu should not be paginated (10 items max of "default" profile).

/**
 * @brief A Menu interface.
**/
class IMenu : public IMenuInstance
{
public: // The definitions.
	using ItemPosition_t = uint;
	using ItemPositionOnPage_t = uint8;
	using Pagination_t = uint16;

	/**
	 * @brief Enumeration representing the style of a menu item.
	 */
	enum ItemStyle_t : uint8
	{
		MENU_ITEM_ACTIVE =      (1 << 0),       ///< Item is drawn selectable.
		MENU_ITEM_HASNUMBER =   (1 << 1),       ///< Item has number.
		MENU_ITEM_CONTROL =     (1 << 2),       ///< Item is control text (back/next/exit).

		MENU_ITEM_DEFAULT =     (MENU_ITEM_ACTIVE | MENU_ITEM_HASNUMBER),   ///< Item should be drawn normally.
	};

	/**
	 * @brief Enumeration representing the available menu controls.
	 */
	enum ItemControls_t : uint8
	{
		MENU_ITEM_CONTROL_PANEL = 0,                ///< Just a panel with no control buttons.
		MENU_ITEM_CONTROL_BACK_BUTTON = (1 << 0),   ///< Back button.
		MENU_ITEM_CONTROL_NEXT_BUTTON = (1 << 1),   ///< Next button.
		MENU_ITEM_CONTROL_EXIT_BUTTON = (1 << 2),   ///< Exit button.

		MENU_ITEM_CONTROL_DEFAULT = (MENU_ITEM_CONTROL_BACK_BUTTON | MENU_ITEM_CONTROL_NEXT_BUTTON | MENU_ITEM_CONTROL_EXIT_BUTTON),    //< Default controls.
	};

	/**
	 * @brief A Item Handler for handling menu item actions.
	 */
	class IItemHandler
	{
	public:
		/**
		 * @brief Called when a menu item is selected.
		 *
		 * @param pMenu         Pointer to the menu instance.
		 * @param aSlot         The player index/slot interacting with the menu.
		 * @param iItem         The selected item position.
		 * @param iItemOnPage   The position of the item on the current page.
		 * @param pData         Additional data associated with the menu item.
		 */
		virtual void OnMenuSelectItem(IMenuInstance *pMenu, CPlayerSlot aSlot, ItemPosition_t iItem, ItemPositionOnPage_t iItemOnPage, void *pData) {}
	};

	struct Title_t
	{
		CUtlString m_sText;                         ///< A title text.
	};

	struct Item_t
	{
		ItemStyle_t m_eStyle = MENU_ITEM_DEFAULT;   ///< A style flags of the item.
		CUtlString m_sContent;                      ///< A content of the item.

		IItemHandler *m_pHandler = nullptr;         ///< The handler for item actions.
		void *m_pData = nullptr;                    ///< Additional data passed to item actions.
	};
	using Items_t = CUtlVector<Item_t>;

public: // Public methods.
	/**
	 * @brief Gets a reference to the menu title.
	 * 
	 * @return Reference to the menu title.
	 */
	virtual Title_t &GetTitleRef() = 0;

	/**
	 * @brief Gets a reference to the collection of menu items.
	 * 
	 * @return Reference to the collection of menu items.
	 */
	virtual Items_t &GetItemsRef() = 0;

	/**
	 * @brief Gets a reference to the menu controls.
	 * 
	 * @return Reference to the menu controls.
	 */
	virtual ItemControls_t &GetItemControlsRef() = 0;

	/**
	 * @brief Displays the menu to a specific player.
	 * NOTE: This method is internal, use IMenuSystem to display.
	 * 
	 * @param aSlot         The player index/slot.
	 * 
	 * @return True if the menu was displayed successfully, false otherwise.
	 */
	inline bool InternalDisplay(CPlayerSlot aSlot)
	{
		return InternalDisplayAt(aSlot, MENU_FIRST_ITEM_INDEX);
	}

	/**
	 * @brief Displays the menu starting from a specific item.
	 * NOTE: This method is internal, use IMenuSystem to display.
	 * 
	 * @param aSlot         The player index/slot.
	 * @param iStartItem    The starting item position (default: 0).
	 * 
	 * @return              `true` if the menu was displayed successfully, 
	 *                      `false` otherwise.
	 */
	virtual bool InternalDisplayAt(CPlayerSlot aSlot, ItemPosition_t iStartItem = 0) = 0;
}; // IMenuInstance

#endif // _INCLUDE_METAMOD_SOURCE_IMENU_HPP_
